package net.lrivas.sumas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Creando las variables
    Button btnCalcular;
    EditText txtCaja1, txtCaja2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referenciamos los objetos
        btnCalcular = findViewById(R.id.btnCalcular);
        txtCaja1 = findViewById(R.id.cajaNumero1);
        txtCaja2 = findViewById(R.id.cajaNumero2);

        //Asignamos el evento Click
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Aqui introducimos nuestro código del boton
                int numero1 = Integer.parseInt(txtCaja1.getText().toString());
                int numero2 = Integer.parseInt(txtCaja2.getText().toString());
                int resultado = numero1 + numero2;
                //Mostramos el resultado en pantalla
                Toast.makeText(MainActivity.this, "La suma es: "+ resultado, Toast.LENGTH_LONG).show();
            }
        });
    }
}
